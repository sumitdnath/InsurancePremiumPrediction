from setuptools import setup,find_packages


setup(name="src",version="1.0",description="my intenship project using MLOPS",packages=find_packages(),
      license="MIT")


