
def test_function():
    a=2
    b=2
    assert a==b